module RbtcArbitrage
  VERSION = "2.4.4"
end
